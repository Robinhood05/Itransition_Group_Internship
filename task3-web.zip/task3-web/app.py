from flask import Flask, request, Response

app = Flask(__name__)

def gcd(a: int, b: int) -> int:
    while b:
        a, b = b, a % b
    return a

def lcm_of_two(a: int, b: int) -> int:
    if a == 0 or b == 0:
        return 0
    return a * b // gcd(a, b)

@app.route("/sajibulislampersonal_gmail_com")
def calculate_lcm():
    x = request.args.get("x")
    y = request.args.get("y")

    if x is None or y is None:
        return Response("NaN", mimetype="text/plain")

    if not (x.isdigit() and y.isdigit()):
        return Response("NaN", mimetype="text/plain")

    a = int(x)
    b = int(y)

    result = lcm_of_two(a, b)

    return Response(str(result), mimetype="text/plain")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
